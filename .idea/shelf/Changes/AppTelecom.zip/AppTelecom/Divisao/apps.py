from django.apps import AppConfig


class DivisaoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Divisao'
