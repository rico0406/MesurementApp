from django.apps import AppConfig


class InspecaoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Inspecao'
